﻿using BillingSystem.Models;
using BillingSystem.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace BillingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BillingController : ControllerBase
    {
        private readonly IBillingService _billingService;
        public BillingController(IBillingService billingService)
        {
            _billingService = billingService;
        }
        [HttpGet]
        public List<Payments> Calculate(StreamContent streamContent)
        {
            //streamContent is the excel data uploaded
            RootModel data = JsonConvert.DeserializeObject<RootModel>(streamContent.ToString());

            return _billingService.BillingCalculator(data);

        }
    }
}
