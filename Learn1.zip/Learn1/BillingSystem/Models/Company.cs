﻿namespace BillingSystem.Models
{
    public class Company
    {
        public Customer customer { get; set; }
        public List<Project> projects { get; set; }
    }    
}
