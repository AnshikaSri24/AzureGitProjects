﻿namespace BillingSystem.Models
{
    public class Customer
    {
        public List<Project> projects { get; set; }
    }
}
