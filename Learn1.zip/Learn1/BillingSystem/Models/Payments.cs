﻿using BillingSystem.Helpers;

namespace BillingSystem.Models
{
    public class Payments
    {
        public DateTime date { get;set; }
        public PaymentType type { get;set; }
        public decimal amount { get;set; }
    }
}
