﻿namespace BillingSystem.Models
{
    public class RootModel
    {
        public Company company { get; set; }
    }
}
