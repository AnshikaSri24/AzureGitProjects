﻿using BillingSystem.Helpers;

namespace BillingSystem.Models
{
    public class Project
    {
        public string projectName { get; set; }
        public BillingModes billingModes { get; set; }
        public List<Payments> payments { get; set; }
    }
}
