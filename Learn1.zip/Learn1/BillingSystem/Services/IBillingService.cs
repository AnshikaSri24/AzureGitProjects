﻿using BillingSystem.Models;

namespace BillingSystem.Services
{
    public interface IBillingService
    {
        List<Payments> BillingCalculator(RootModel rootModel);
    }
}
