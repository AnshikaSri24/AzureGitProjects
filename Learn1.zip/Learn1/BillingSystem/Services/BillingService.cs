﻿using BillingSystem.Models;

namespace BillingSystem.Services
{
    public class BillingService : IBillingService
    {
        public List<Payments> BillingCalculator(RootModel rootModel)
        {
            List<Payments> matchedInvoices = new List<Payments>();
            //we need to check the DB for invoice match //DBConnection
            List<decimal> invoice = new List<decimal> { 100, 200 };
            decimal invoiceSum = invoice.Select(x => x).Sum();
            foreach (var item in rootModel.company.projects)
            {
                if (item == null) continue;
                foreach (var paymentData in item.payments)
                {
                    if (invoice.Any(a => a == paymentData.amount))
                    {
                        matchedInvoices.Add(paymentData);
                    }
                    else if (paymentData.amount == invoiceSum)
                    {
                        matchedInvoices.Add(paymentData);
                    }
                    else
                    {
                        Console.WriteLine("Invalid Payment");
                    }
                }
            }
            return matchedInvoices;
        }
    }
}
