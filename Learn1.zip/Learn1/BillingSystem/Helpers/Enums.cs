﻿namespace BillingSystem.Helpers
{
    public enum BillingModes
    {
        Time_Material,
        Milestone_Based
    }
    public enum PaymentType
    {
        Debit,
        Credit
    }
    public enum Month
    {
        January,
        Feburary,
        March,
        April,
        May,
        June,
        July, 
        August,
        September,
        October,
        November,
        December
    }
}
